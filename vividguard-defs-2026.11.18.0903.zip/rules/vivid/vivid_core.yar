/*
    VividGuard core rules (c) Vivid Software.
    Meta used by VividGuard: threat (display name), severity (low|medium|high|critical), description.
    Each rule needs a combination of indicators so one common string can't trigger it on its own.
*/

rule VG_Test_EICAR
{
    meta:
        threat = "Test.EICAR"
        severity = "low"
        description = "The standard EICAR anti-malware test file. It is harmless and exists to test scanners"
    strings:
        $eicar = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
    condition:
        $eicar at 0 and filesize < 256
}

rule VG_Script_PowerShell_HiddenEncodedLauncher
{
    meta:
        threat = "Trojan.PowerShell.HiddenLauncher"
        severity = "high"
        description = "Starts PowerShell with a long encoded command and hides its window or bypasses script policy, a common way to run malware unseen"
    strings:
        $ps = "powershell" nocase ascii wide
        $enc = /-(e|en|enc|enco|encod|encodedcommand)\s+[A-Za-z0-9+\/]{60,}/i
        $hidden = /-w(i|in|ind|indo|indow|indows|indowstyle)?\s+h(idden)?\b/i
        $bypass = /-ex(ecutionpolicy|ec)?\s+bypass/i
        $nop = /\s-nop(rofile)?\b/i
    condition:
        filesize < 5MB and $ps and $enc and ($hidden or $bypass or $nop)
}

rule VG_Script_PowerShell_DownloadCradle
{
    meta:
        threat = "Suspicious.PowerShell.DownloadCradle"
        severity = "medium"
        description = "Downloads code from the internet and runs it immediately in memory without saving it first"
    strings:
        // IEX (New-Object Net.WebClient).DownloadString(...) / IEX (iwr ...) / Invoke-Expression (Invoke-RestMethod ...)
        $run_download = /\b(iex|invoke-expression)\s*\(?\s*\(?\s*(new-object\s+(system\.)?net\.webclient|\[system\.net\.webclient\]|iwr\b|irm\b|invoke-webrequest|invoke-restmethod|wget\b|curl\b)/ nocase ascii wide
        // (New-Object Net.WebClient).DownloadString(...) | iex   /   irm https://... | iex
        $download_pipe = /(downloadstring|downloaddata|iwr\b|irm\b|invoke-webrequest|invoke-restmethod)[^\r\n|]{0,300}\|\s*(iex|invoke-expression)\b/ nocase ascii wide
    condition:
        filesize < 2MB and uint16(0) != 0x5A4D and any of them
}

rule VG_Script_DisableDefender
{
    meta:
        threat = "Trojan.Script.DefenderTamper"
        severity = "high"
        description = "Tries to switch off Microsoft Defender's real-time, behavior or download protection"
    strings:
        $set = "Set-MpPreference" nocase ascii wide
        $o1 = "-DisableRealtimeMonitoring $true" nocase ascii wide
        $o2 = "-DisableRealtimeMonitoring 1" nocase ascii wide
        $o3 = "-DisableBehaviorMonitoring $true" nocase ascii wide
        $o4 = "-DisableIOAVProtection $true" nocase ascii wide
        $o5 = "-DisableScriptScanning $true" nocase ascii wide
        $reg1 = "DisableAntiSpyware" nocase ascii wide
        $reg2 = "DisableRealtimeMonitoring" nocase ascii wide
        $regpath = "\\Policies\\Microsoft\\Windows Defender" nocase ascii wide
    condition:
        filesize < 10MB and uint16(0) != 0x5A4D and (($set and any of ($o*)) or ($regpath and any of ($reg*)))
}

rule VG_Behavior_RecoveryDestruction
{
    meta:
        threat = "Ransomware.Generic.RecoveryWipe"
        severity = "critical"
        description = "Deletes Windows shadow copies and disables recovery, the usual first step of ransomware before encrypting files"
    strings:
        $v1 = "vssadmin delete shadows" nocase ascii wide
        $v2 = "vssadmin.exe delete shadows" nocase ascii wide
        $v3 = "shadowcopy delete" nocase ascii wide
        $v4 = "delete shadows /all" nocase ascii wide
        $b1 = "recoveryenabled no" nocase ascii wide
        $b2 = "bootstatuspolicy ignoreallfailures" nocase ascii wide
        $b3 = "wbadmin delete catalog" nocase ascii wide
        $b4 = "wbadmin delete systemstatebackup" nocase ascii wide
    condition:
        filesize < 20MB and any of ($v*) and any of ($b*)
}

rule VG_HackTool_Mimikatz
{
    meta:
        threat = "HackTool.Mimikatz"
        severity = "high"
        description = "Mimikatz, a tool that extracts passwords and credentials from Windows memory"
    strings:
        $s1 = "sekurlsa::logonpasswords" nocase ascii wide
        $s2 = "gentilkiwi" nocase ascii wide
        $s3 = "lsadump::sam" nocase ascii wide
        $s4 = "kerberos::golden" nocase ascii wide
        $s5 = "privilege::debug" nocase ascii wide
        $s6 = "mimikatz" nocase ascii wide
    condition:
        uint16(0) == 0x5A4D and 3 of them
}

rule VG_HackTool_InvokeMimikatz
{
    meta:
        threat = "HackTool.PowerShell.InvokeMimikatz"
        severity = "high"
        description = "A PowerShell script that loads Mimikatz to dump Windows credentials"
    strings:
        $f = "Invoke-Mimikatz" nocase ascii wide
        $a1 = "DumpCreds" nocase ascii wide
        $a2 = "sekurlsa::" nocase ascii wide
        $a3 = "Invoke-ReflectivePEInjection" nocase ascii wide
        $a4 = "PEBytes64" nocase ascii wide
    condition:
        filesize < 10MB and uint16(0) != 0x5A4D and $f and 2 of ($a*)
}

rule VG_Script_WSH_DownloadExecute
{
    meta:
        threat = "Trojan.Script.Downloader"
        severity = "high"
        description = "A Windows Script Host script that downloads a file, saves it to disk and runs it"
    strings:
        $http1 = "MSXML2.XMLHTTP" nocase ascii wide
        $http2 = "MSXML2.ServerXMLHTTP" nocase ascii wide
        $http3 = "WinHttp.WinHttpRequest" nocase ascii wide
        $save1 = "ADODB.Stream" nocase ascii wide
        $save2 = "SaveToFile" nocase ascii wide
        $shell1 = "WScript.Shell" nocase ascii wide
        $shell2 = "Shell.Application" nocase ascii wide
        $run1 = ".Run" nocase ascii wide
        $run2 = "ShellExecute" nocase ascii wide
    condition:
        filesize < 2MB and uint16(0) != 0x5A4D and any of ($http*) and all of ($save*) and any of ($shell*) and any of ($run*)
}

rule VG_Shortcut_ScriptLauncher
{
    meta:
        threat = "Trojan.LNK.ScriptLauncher"
        severity = "high"
        description = "A shortcut that launches a script engine with download, hidden-window or encoded-command options"
    strings:
        $p1 = "powershell" nocase ascii wide
        $p2 = "mshta" nocase ascii wide
        $p3 = "wscript" nocase ascii wide
        $p4 = "cscript" nocase ascii wide
        $p5 = "rundll32" nocase ascii wide
        $p6 = "certutil" nocase ascii wide
        $x1 = "http://" nocase ascii wide
        $x2 = "https://" nocase ascii wide
        $x3 = "-enc" nocase ascii wide
        $x4 = "hidden" nocase ascii wide
        $x5 = "frombase64string" nocase ascii wide
        $x6 = "javascript:" nocase ascii wide
        $x7 = "-urlcache" nocase ascii wide
    condition:
        uint32(0) == 0x0000004C and filesize < 2MB and any of ($p*) and 2 of ($x*)
}

rule VG_Script_HTA_ShellRunner
{
    meta:
        threat = "Trojan.HTA.Runner"
        severity = "high"
        description = "An HTML application that runs shell commands or PowerShell through ActiveX when opened"
    strings:
        $hta = "<hta:application" nocase ascii wide
        $ax = "ActiveXObject" nocase ascii wide
        $sh = "WScript.Shell" nocase ascii wide
        $r1 = "powershell" nocase ascii wide
        $r2 = "cmd /c" nocase ascii wide
        $r3 = "cmd.exe /c" nocase ascii wide
        $r4 = ".Run(" nocase ascii wide
    condition:
        filesize < 5MB and $ax and $sh and ($hta or 2 of ($r*)) and any of ($r*)
}

rule VG_Script_Certutil_Download
{
    meta:
        threat = "Suspicious.Script.CertutilDownloader"
        severity = "medium"
        description = "Uses the Windows certificate tool (certutil) to download or decode a file, a well-known way to sneak payloads past defenses"
    strings:
        $c = "certutil" nocase ascii wide
        $u1 = "-urlcache" nocase ascii wide
        $u2 = "/urlcache" nocase ascii wide
        $d1 = "-decode" nocase ascii wide
        $d2 = "/decode" nocase ascii wide
        $http = "http" nocase ascii wide
    condition:
        filesize < 2MB and uint16(0) != 0x5A4D and $c and ((any of ($u*) and $http) or (any of ($d*) and any of ($u*)))
}
